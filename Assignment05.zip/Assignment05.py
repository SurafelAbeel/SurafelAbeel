# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Surafel Abeel
# Date:  November 18, 2018
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

#Step 1: Write a text file called "Todo.txt" and write the following info using the command "w" to write
Todofile = open ("C:\PythonClass\Assignment05\Todo.txt", "w")  #Opens and writes in a text file
Todofile.write("Clean House,low\n")  #Writes the first line, usedn "\n" command to begin  a new line
Todofile.write("Pay Bills,high")     #Writes the second line
Todofile.close                       #Closes file

#2 Now we need to inport the txt file back to Python in a dictionalry form
Todofile = open("C:\PythonClass\Assignment05\Todo.txt", "r")  #use "r" command to read txt file
lines = Todofile.readlines()  #use "readlines" command to read line by line of txt file
#print (Todofile.read())
dicRow1 = (lines[0])  # dicRow1 is referring to the first content in that 1st line
dicRow1 = dicRow1.split(",") # use "split" command to split the content using ","
#print(dicRow1)
dicRow2 = (lines[1]) # similar to dicRow1 but accessing line 2 this time
dicRow2 = dicRow2.split(",") #Splitting content
#print(dicRow2)


dicrow1 = {dicRow1[0]: dicRow1[1]} #Making a dictionary for each row (row 1)
dicrow2 = {dicRow2[0]: dicRow2[1]} #Making a dictionary for each row (row 2)

#3: Add new dictionary row into a Python list object

lstTable = [dicrow1, dicrow2] #Putting our dictionary rows into a list Table

#4: Display contents of list to user

print (lstTable)

#5:  - Display a menu of choices to the user

while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)  #List of menu for user to choose
    strChoice = str(input("Which option would you like to perform? [1 to 5] ")) #User gets to select from Menu list
    print()  # adding a new line

        # Option 1: Show the current items in the table
    if (strChoice == "1"):
            print(lstTable) #if option 1 is selected, print out data per instruciton
        # Option 2: Add a new item to the list/Table
    elif (strChoice == "2"): #if option 2 is selected, input will be added to list
        newElem = str(input("Type out what you'd like to add to the data: Type in format (Key,Value) ")).split(",")
        lstTable.append({newElem[0]: newElem[1]})#append command adds input to data

        # Option 3: Remove a new item to the list/Table
    elif (strChoice == "3"):
        removeinput = str(input ("Type out exactly what you'd like to remove from the data: Type in format (Key, Value) ")).split(",")
        if {removeinput[0]: removeinput[1]} in lstTable:
            lstTable.remove({removeinput[0]: removeinput[1]})#remove deletes input from data
        # Option 4: Save tasks to the ToDo.txt file
    elif (strChoice == "4"):
        Todofile = open("C:\PythonClass\Assignment05\Todo.txt", "a") #using "a" adds to exiting, whereas "w" writes
                                                                     #over existing data creating new txt file.
        Todofile.write("\n"+str(lstTable)) #using "\n" command to begin a new line
        Todofile.close()  #close data after saving
        #Option 5: break and exit program
    elif (strChoice == "5"): break

       #END
